import firebase from 'firebase';

// Firebase configuration (copy from firebase app setup)
let firebaseConfig = {
    // TODO: Replace with personal Firebase project config
}

firebase.initializeApp(firebaseConfig);

// TODO: Export Firestore
