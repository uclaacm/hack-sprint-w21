import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { View, Text, Image, SafeAreaView } from 'react-native';
// TODO: make sure you import StyleSheet from 'react-native'

export default function App() {
    return (
    <SafeAreaView style={styles.container}>
        <StatusBar style="auto" />
        <View>
            {/* TODO: Add styles to each of these */}
          <Text>Unstyled text</Text>
          <Text>Make this text red</Text>
          <Text>Make this text large</Text>
          <Text>Put space around this text</Text>
          <Text>Red and large</Text>
          <Text>Large then lowercase</Text>
          <Text>Lowercase then large</Text>
        </View>
        <View>
            <Image
                style={{
                    width: 100,
                    height: 100
                }}
                source={require('./images/roasted_oolong.jpg')} 
            />
            <Text>Let's put a border around this box</Text>
        </View>
        <View>
            <Image
                style={{
                    width: 100,
                    height: 100
                }}
                source={{
                  uri: 'https://tarasmulticulturaltable.com/wp-content/uploads/2014/02/Niku-Udon-Japanese-Meat-Udon-4-of-5-e1573750889431.jpg'
                }}
            />
            <Text>Let's make this container super crazy!</Text>
        </View>
    </SafeAreaView>
    );
}

// TODO: Create styles object and styles for the given tasks