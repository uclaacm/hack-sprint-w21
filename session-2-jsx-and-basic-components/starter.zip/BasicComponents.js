import { StatusBar } from 'expo-status-bar';
import React from 'react';
// TODO: remember to import components from 'react-native'

export default function App() {

    return (
    <View>
        <StatusBar style="auto" />
        {/* TODO: Mess around with different components */}
    </View>
    );
}